<?php
class Stud_Rec extends CI_Controller{
	
	public function __construct(){
		
		parent::__construct();
		$this->load->model("stud_record_model");
		$this->load->helper("url_helper");
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library('table');
		
		
	}
	
	public function index()
	{
		$template = array(
        'table_open'            => '<table border="2" cellpadding="4" cellspacing="1" style="text-align:center;">',

        'thead_open'            => '<thead>',
        'thead_close'           => '</thead>',

        'heading_row_start'     => '<tr>',
        'heading_row_end'       => '</tr>',
        'heading_cell_start'    => '<th>',
        'heading_cell_end'      => '</th>',

        'tbody_open'            => '<tbody>',
        'tbody_close'           => '</tbody>',

        'row_start'             => '<tr>',
        'row_end'               => '</tr>',
        'cell_start'            => '<td>',
        'cell_end'              => '</td>',

        'row_alt_start'         => '<tr>',
        'row_alt_end'           => '</tr>',
        'cell_alt_start'        => '<td>',
        'cell_alt_end'          => '</td>',

        'table_close'           => '</table>'
);
			$data['stud'] = $this->stud_record_model->get_std_record();
			$data['title'] = 'Student Database';		
			$query = $this->db->query('SELECT * FROM stud');
			$this->table->set_caption('Student Data');
			$this->table->set_heading('Sr No', 'Roll No','Name');
			$this->table->set_template($template);
			$data['table']= $this->table->generate($query);
			
			
			$list = array('one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve');
			$new_list = $this->table->make_columns($list, 3);
			$data['list'] =$this->table->generate($new_list);		
			
			$this->load->library('user_agent');

if ($this->agent->is_browser())
{
        $agent = $this->agent->browser().' '.$this->agent->version();
}
elseif ($this->agent->is_robot())
{
        $agent = $this->agent->robot();
}
elseif ($this->agent->is_mobile())
{
        $agent = $this->agent->mobile();
}
else
{
        $agent = 'Unidentified User Agent';
}

echo $agent;

echo $this->agent->platform();
			
			
			
			
			
			$this->load->view('templates/header', $data);
			$this->load->view('std_rec/index', $data);
			$this->load->view('templates/footer');		
			
	}
	
	public function add_record()
	{
		 
		 $data['title'] = 'Add Student Record';
		 
		 $this->form_validation->set_rules('rollno',"Roll Number", "required");
		 $this->form_validation->set_rules('name',"Name", "required");
		  
		 if($this->form_validation->run()===FALSE)
		 {
			
			$this->load->view('templates/header', $data);
			$this->load->view('std_rec/add_record');
			$this->load->view('templates/footer'); 
		 }
		 else
		 {
			 $this->stud_record_model->insert_data();
			 $data['insert_sucess']='Your data is sucessfully added!';
			 $this->load->view('std_rec/sucessfull',$data); 
		 }	
	}
	
	public function view_record()
	{
		$data['stud'] = $this->stud_record_model->get_std_record();
		$data['title'] = 'View Records';
			$this->load->view('templates/header', $data);
			$this->load->view('std_rec/view_record', $data);
			$this->load->view('templates/footer');
	}	
		
		public function edit_record()
		{
			$roll_no= $this->uri->segment('3');
			
			$data['stud'] = $this->stud_record_model->get_record($roll_no);
			$data['title'] = 'Edit Record';
			$this->load->view('templates/header', $data);
			$this->load->view('std_rec/edit_record',$data);
			$this->load->view('templates/footer');
		}
		
	public function update_record(){
		
		$srno=$this->input->post('srno');
		$this->stud_record_model->update_data($srno);
		//$data['update_sucess']='Your data is sucessfully Updated';
		$this->load->view('std_rec/sucessfull'); 
		
	}
	public function delete_record(){
		$roll_no= $this->uri->segment('3');
		$this->stud_record_model->delete_data($roll_no);
		$this->load->view('std_rec/sucessfull'); 
		
	}
	
	
}

?>