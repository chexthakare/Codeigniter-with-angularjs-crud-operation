<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class App extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('app_model');
	}

	public function index()
	{
		$this->load->view('main');
		
	}
	public function view()
	{	
		$this->load->view('std_rec/view_record');
	}
	public function home()
	{		
		$this->load->view('std_rec/home');
	}
	public function add()
	{
		$this->load->view('std_rec/add_record');
	}
	public function updatedata(){
		
		$this->load->view('std_rec/update.php');
	}
	public function deletedata()
	{
		$this->load->view('std_rec/delete.php');
	}
	public function insert_record()
	{
		$userdata = json_decode(file_get_contents("php://input"));		
		$this->app_model->insert_data($userdata);
	}

	public function edit()
	{
		$this->load->view('std_rec/edit_record');
	}
	public function update_record(){
		
		$userdata = json_decode(file_get_contents("php://input"));	
		$this->app_model->update_data($userdata);
		
	}
	public function delete_record(){
		$userdata = json_decode(file_get_contents("php://input"));
		$roll_no = $userdata->roll_no;
		$this->db->delete("stud","roll_no=$roll_no");
	}
	public function get_data()
	{
		$data = $this->app_model->get_std_record();
		print json_encode($data);
	}
}

/* End of file Main.php */
/* Location: ./application/controllers/Main.php */