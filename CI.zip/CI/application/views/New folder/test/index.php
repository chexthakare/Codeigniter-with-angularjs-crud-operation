<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Online Library</title>

    <!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/custom.css" rel="stylesheet">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href='https://fonts.googleapis.com/css?family=Rokkitt' rel='stylesheet' type='text/css'>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <!-- Start Navigation bar -->
  <nav class="navbar navbar-default navbar-fiexed-top">
	<div class="container">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
			<span class="sr-only">Toggle Navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
				<a class="navbar-brand" href="index.php">Online Library</a></b>
		<div class="navbar-collapse collapse">
			<ul class="nav navbar-nav navbar-right">
				<li class="active"><a href="index.php">Home</a></li>  
				<li ><a href="about.php">About</a></li>  
				<li ><a href="contact.php">Contact Us</a></li>  
				<li ><a href="#signin.php">Sign In</a></li>  
			</ul>
		</div>
	</div>
  </nav>
<!-- End Navigation bar -->
<!--Start carousel -->
<div class="container">
  <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="5000">
	  <div class="carousel-inner" role="listbox">
			<div class="item active">
			  <img src="img/1.jpg" class="img-responsive" alt="onlinelibrary">
			</div>
			<div class="item">
			  <img src="img/2.jpg" class="img-responsive" alt="onlinelibrary">
			</div>
	  </div>
  </div>

 </div>
 <!--End carousel -->
  </br>
<!--Start of Categories -->	
<div class="container">
<div align="center" class = "btn btn-success btn-lg btn-block"><h1>Categories</h1></div>
<br><br>
<div class="row">
<?php 
session_start();
include 'dbconnection\connection.php';
								
	$result =  mysql_query("SELECT * FROM category");
	while($row= mysql_fetch_array($result))
	{
		
		$name=$row['Category Name'];
		$image=$row['Category Name'];
		$link=$row['link'];
		$id=$row['bookscat'];//need to pass this
?>
<!--from here this is in loop-->
		<div class="col-md-3">
			<div class = "panel panel-success">
			<div class = "panel-heading"><center><h4><?php echo $name?></h4></center></div>
			<div class = "panel-body"><center>

				<a href="books.php?id=<?php echo $id; ?>" > 
				
				<img src="catimg/<?php echo $image; ?>.png" alt="<?php echo $image; ?>" height="200px" width="150px"/>
			</a>
			</a></center>
			</div>
		</div>
	</div>
<?php }?>
</div>

<!--End of Categories -->	
  
  


 <!--Footer start here-->
<footer>
    <div class="footer" id="footer">
	<!--Footer1 start here-->
	  <div class="jumbotron">
	  <div class="container">
	  <div class="row" >
	  <div class="col-md-4" style="margin:5px;">
	   <p style="color: #ffffff; font-family: 'Rokkitt', serif; font-size:30px;">Receive the latest Update</p>
	  </div>
	  
		<div class="col-md-4" style="margin:5px;">
			<div class="input-group margin-bottom-sm">
					<span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
					<input class="form-control" type="text" placeholder="Email address">
					
			</div>
			<ul class="social">
                        <li> <a href="#"> <i class="fa fa-facebook fa-5x">   </i> </a> </li>
                        <li> <a href="#"> <i class="fa fa-twitter fa-5x">   </i> </a> </li>
                        <li> <a href="#"> <i class="fa fa-google-plus fa-5x">   </i> </a> </li>
                        <li> <a href="#"> <i class="fa fa-youtube fa-5x">   </i> </a> </li>
                 </ul>
		</div>
		<div class="col-md-2" style="margin:5px;">
			<div class="btn-group open">
				<a class="btn btn-success" href="#" style="color:#fff;"><i class="fa fa-user fa-fw"></i> Sign Up</a>
			</div>
	  </div>
			<div class="col-lg-3  col-md-2 col-sm-6 col-xs-12 ">
                    
			</div>
	  </div>
	  </div>
	  </div>
	 <!--Footer1 end here--> 
        <div class="container">
            <div class="row">
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
                    <h3> Lorem Ipsum </h3>
                    <ul>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                    </ul>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
                    <h3> Lorem Ipsum </h3>
                    <ul>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                    </ul>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
                    <h3> Lorem Ipsum </h3>
                    <ul>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                    </ul>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
                    <h3> Lorem Ipsum </h3>
                    <ul>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                    </ul>
                </div>
            </div>
            <!--/.row--> 
        </div>
        <!--/.container--> 
    </div>
    <!--/.footer-->
    
    <div class="footer-bottom">
        <div class="container">
            <p class="pull-left"> Copyright © <a href="#"><img src="img/text-logo.gif"></a> 2016 - 2017. All right reserved. </p>
            <div class="pull-right">
                <ul class="nav nav-pills payments">
                	<li><i class="fa fa-cc-visa" ></i></li>
                    <li><i class="fa fa-cc-mastercard"></i></li>
                    <li><i class="fa fa-cc-amex"></i></li>
                    <li><i class="fa fa-cc-paypal"></i></li>
                </ul> 
            </div>
        </div>
    </div>
    <!--/.footer-bottom--> 
</footer>
  <!--footer end here-->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
