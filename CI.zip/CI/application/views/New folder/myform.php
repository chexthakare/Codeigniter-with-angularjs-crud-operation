<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Form</title>
    <!-- Bootstrap -->
	<link href="<?php echo base_url("asset/js/bootstrap.min.js"); ?>" rel="text/javascript">
	<link href="<?php echo base_url("asset/js/jquery-3.1.0.min.js"); ?>" rel="text/javascript">
	<link href="<?php echo base_url("asset/css/bootstrap.min.css"); ?>" rel="stylesheet">
	<link href="<?php echo base_url("asset/css/bootstrap-theme.min.css"); ?>" rel="stylesheet">
	
	<!--End of Bootstrap-->
	<script>
	<?php echo $library_src;?>
	<?php echo $script_head;?>
	</script>
</head>
  <body>
    <!-- Start Navigation bar -->
  <nav class="navbar navbar-default navbar-fiexed-top">
	<div class="container">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
			<span class="sr-only">Toggle Navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
				<a class="navbar-brand" href="index.php">Online Library</a></b>
		<div class="navbar-collapse collapse">
			<ul class="nav navbar-nav navbar-right">
				<li class="active"><a href="index.php">Home</a></li>  
				<li ><a href="about.php">About</a></li>  
				<li ><a href="contact.php">Contact Us</a></li>  
				<li ><a href="signin.php">Sign In</a></li>  
			</ul>
		</div>
	</div>
  </nav>
<!-- End Navigation bar -->


<?php echo form_open('form'); ?>

<h5>Username</h5>
<input type="text" name="username" value="<?php echo set_value('username');?>" size="50" />
<span><?php echo form_error('username'); ?></span>

<h5>Password</h5>
<input type="text" name="password" value="<?php echo set_value('password');?>" size="50" />
<?php echo form_error('password'); ?>

<h5>Password Confirm</h5>
<input type="text" name="passconf" value="<?php echo set_value('passconf');?>" size="50" />
<?php echo form_error('passconf'); ?>

<h5>Email Address</h5>
<input type="text" name="email" value="<?php echo set_value('email');?>" size="50" />
<?php echo form_error('email'); ?>
<div><input type="submit" value="Submit" /></div>
</form>

</body>
</html>