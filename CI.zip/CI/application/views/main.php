<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head> 
		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       
        <title>CodeIgniter Tutorial</title>
		
		<link href="<?php echo base_url("assets/bootstrap.min.css"); ?>" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular-route.js"></script>
		<script src="<?php echo base_url() ?>assets/js/app.js"></script>
		</head>

<body>
<div class="container">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Student Records</a>
    </div>
    <ul class="nav navbar-nav" id="mainmenu">
     <!-- <li class="active"><?php //echo anchor('sdms/home', 'Home')?></li>
	  <li><?php// echo anchor('sdms/view','View Records')?></li>
      <li><?php// echo anchor('sdms/add', 'Add Records')?></li>
      <li><?php// echo anchor('sdms/update','Update Records')?></li>
      <li><?php// echo anchor('sdms/delete','Delete Records')?></li>-->
	  
	  <li class="active"><?php echo anchor('#/home', 'Home')?></li>
	  <li><?php echo anchor('#/view','View Records')?></li>
      <li><?php echo anchor('#/add', 'Add Records')?></li>
      <li><?php echo anchor('#/update','Update Records')?></li>
      <li><?php echo anchor('#/delete','Delete Records')?></li>
    </ul>
  </div>
</nav>
<div class="panel panel-default"> 
	<div class="panel-heading"> 

	
	
	
	</div> 
<div class="panel-body"> 
	<div ng-view>
		
	
	</div>


</div> 
<div class="panel-footer" style="padding-top:30px;padding-bottom:30px;" >
<?php  
	if($this->session->flashdata('update_success')!=NULL OR $this->session->flashdata('insert_success')!=NULL OR  $this->session->flashdata('delete_success')!=NULL)
	{
		echo "<span class='alert alert-success'>";
		echo	$this->session->flashdata('update_success');
		echo    $this->session->flashdata('insert_success');
		echo    $this->session->flashdata('delete_success');
		echo  "</span>";
	}
?> 
</div>
</div>  
</div>


</body>
</html>