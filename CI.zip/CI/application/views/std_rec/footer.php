
</div> 
<div class="panel-footer" style="padding-top:30px;padding-bottom:30px;" >
	<?php  
		if($this->session->flashdata('update_success')!=NULL OR $this->session->flashdata('insert_success')!=NULL OR  $this->session->flashdata('delete_success')!=NULL)
		{
			echo "<span class='alert alert-success'>";
			echo	$this->session->flashdata('update_success');
			echo    $this->session->flashdata('insert_success');
			echo    $this->session->flashdata('delete_success');
			echo  "</span>";
		}
	?> 
</div>
</div>  
</div>
</body>
</html>