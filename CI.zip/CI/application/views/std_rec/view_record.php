<h5><center> {{title}} </center></h5>
<table class="table table-striped">
<tr>

<th>Roll No</th>
<th>First Name</th>
<th>Middle Name</th>
<th>Last Name</th>
<th>Contact No</th>
<th>Email</th>
</tr>

<?php//$i = 1; foreach ($stud as $std_rec){?>
<tr>
<td><?php	//echo  $i++; ?></td>
<td><?php	//echo  $std_rec['roll_no']; ?></td>
<td><?php	//echo $std_rec['firstname'];?></td>
<td><?php	//echo $std_rec['middlename'];?></td>
<td><?php	//echo $std_rec['lastname'];?></td>
<td><?php	//echo $std_rec['contactno'];?></td>
<td><?php	//echo $std_rec['email'];?></td>
</tr>
<?php
//} ?>

<tr ng-repeat="student in students">
<td>{{ student.roll_no }}	</td>
<td>{{ student.firstname }}	</td>
<td>{{ student.middlename }}</td>
<td>{{ student.lastname }}	</td>
<td>{{ student.contactno }}	</td>
<td>{{ student.email }}		</td>
</tr>

</table>
