'use strict';
var myApp = angular.module('myApp', ['ngRoute']);
myApp.config(['$routeProvider', function ($routeProvider) {
	$routeProvider
	.when('/home', {
		templateUrl: 'app/home',
		controller: 'HomeCtrl'
	})
	.when('/view', {
		templateUrl: 'app/view',
		controller: 'ViewCtrl'
		
	})
	.when('/add', {
		templateUrl: 'app/add',
		controller: 'AddCtrl'
	})
	.when('/update', {
		templateUrl: 'app/updatedata',
		controller: 'UpdateCtrl'
	})
	.when('/delete', {
		templateUrl: 'app/deletedata',
		controller: 'DeleteCtrl'
	})
	.otherwise({
		redirectTo: "/home"
	});
	
}]);

myApp.factory('dataservice', function($http) {
	
	return {
		getStudents: function() {
            return $http.get("app/get_data")
        }  
	}

	
});

myApp.controller('HomeCtrl', ['$scope','$http','dataservice', function ($scope,$http,dataservice) {
	$scope.title = 'View Record' ;
	dataservice.getStudents().then(function(res) {
      $scope.students = res.data;
    });
	
}]);
myApp.controller('ViewCtrl', ['$scope','$http','dataservice', function ($scope,$http,dataservice) {
	$scope.title = 'View Record' ;
		dataservice.getStudents().then(function(res) {
      $scope.students = res.data;
    });
	
	
}]);
myApp.controller('UpdateCtrl', ['$scope','$http','dataservice', function ($scope,$http,dataservice) {

	$scope.title = 'Update Record';
	dataservice.getStudents().then(function(res) {
      $scope.students = res.data;
    });
	
	
	$scope.updateData = function(roll_no,firstname, middlename, lastname,contactno,email) {
			 $scope.formtitle	= 'Edit Record';	
			 $scope.roll_no		= roll_no;	
			 $scope.firstname	= firstname;
			 $scope.middlename	= middlename;
			 $scope.lastname 	= lastname;
			 $scope.contactno 	= contactno;	
			 $scope.email 		= email;
			 $scope.editform	= true;
			 
	}
	$scope.updateuserData = function(roll_no,firstname,middlename,lastname,contactno,email) {
		if(firstname==null || middlename==null || lastname==null || contactno==null || email==null) {
			$scope.message_color = "red";
			$scope.message = "All fields are required.";
		} else {
			
			$http.post('app/update_record', {
			'roll_no': 		roll_no, 	//ng-model of textbox name
			'firstname': 	firstname, 	//ng-model of textbox name
			'middlename': 	middlename, 	//ng-model of textbox name
			'lastname': 	lastname, 	//ng-model of textbox name
			'contactno': 	contactno, 	//ng-model of textbox name
			'email': 		email, 		//ng-model of textbox email
			})
			.success(function() {
				
				$scope.message_color = "green";
				$scope.message = "Data Updated.";
				$http.get("app/get_data").then(function(res) {
					$scope.students = res.data;
				});
				roll_no= null;
				firstname = null;
				middlename = null;
				lastname = null;
				contactno = null; //reset textbox values
				email = null; //reset textbox values
				$scope.editform	= false;
			})
			.error(function() {
				console.log("Error");
			})
		}
	}
	
}]);
myApp.controller('DeleteCtrl', ['$scope','$http','dataservice', function ($scope,$http,dataservice) {
	$scope.title = 'Delete Record';
		dataservice.getStudents().then(function(res) {
			$scope.students = res.data;
		});
	$scope.deleteData = function(roll_no) {
		if(confirm("Are you sure you want to delete this record?"))
		{
			$http.post('app/delete_record', {
			'roll_no': roll_no, 	//ng-model of textbox name
			})
			.success(function() {
				$scope.message_color = "green";
				$scope.message = "Data deleted.";
				$http.get("app/get_data").then(function(res) {
					$scope.students = res.data;
				});
			})
			.error(function() {
				console.log("Error");
			})
		}
		else
		{
			return false;
		}
		
	}
	
}]);
myApp.controller('AddCtrl', ['$scope','$http', function ($scope,$http) {
	$scope.title = 'Add Record';
	
	$scope.insertData = function() {
		if($scope.firstname==null || $scope.middlename==null || $scope.lastname==null || $scope.contactno==null || $scope.email==null) {
			$scope.message_color = "red";
			$scope.message = "All fields are required.";
		} else {

			$http.post('app/insert_record', {
			'firstname': 	$scope.firstname, 	//ng-model of textbox name
			'middlename': 	$scope.middlename, 	//ng-model of textbox name
			'lastname': 	$scope.lastname, 	//ng-model of textbox name
			'contactno': 	$scope.contactno, 	//ng-model of textbox name
			'email': 		$scope.email, 		//ng-model of textbox email
			})
			.success(function() {
				$scope.message_color = "green";
				$scope.message = "Success.";
				$scope.firstname = null;
				$scope.middlename = null;
				$scope.lastname = null;
				$scope.contactno = null; //reset textbox values
				$scope.email = null; //reset textbox values
			})
			.error(function() {
				console.log("Error");
			})
		}
	}
}]);