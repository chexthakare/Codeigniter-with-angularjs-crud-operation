angular.module('crudApp')
.controller('UpdateCtrl', ['$scope','$http', function ($scope,$http) {
	$scope.title = 'Update Record';
	$http.get("app/get_data").success(function(result){
                $scope.students = result;
            });
}]);